let x="haxx d00d";
console.log(x);
//playing with random stuff