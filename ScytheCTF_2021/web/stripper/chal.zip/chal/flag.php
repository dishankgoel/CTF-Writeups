<?php
$flag="flag{f4k3_fl4g}";
echo "<h1>I thought you could do better :( </h1>";
?>
