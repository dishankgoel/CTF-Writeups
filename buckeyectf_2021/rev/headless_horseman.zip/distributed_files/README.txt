%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% The Legend of the Headless Horseman %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A mysterious figure has been terrorizing the village of Sleepy Hollow.

He rides a massive horse, swings a mighty scythe and has been collecting heads from any who draw near.

A group of locals, Ichabod Crane, Katrina Van Tassel, and Abraham "Brom Bones" Van Brunt have been working to discover the secret behind this mysterious menace, but just as they were on the verge of putting the pieces together, the Headless Horseman Struck!

All that are left of the heros are some unidentifiable bodies with no heads!

Can you help put our heros back together, and figure out what secrets they uncovered? You'll first need to bargin with the horseman... bring some pumpkins with you.. a LOT of pumpkins.